from game import Agent
from game import Directions

class CompAgent(Agent):
    """ YOUR CODE HERE! """

    def getAction(self, state):
        "The agent receives a GameState (defined in pacman.py)."
        if Directions.WEST in state.getLegalPacmanActions():
            return Directions.WEST
        else:
            return Directions.STOP
